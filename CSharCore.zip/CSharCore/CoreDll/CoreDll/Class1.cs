﻿namespace CoreDll
{
    public class Class1
    {
        public static int finalCalc(int x)
        {
            return (10 * x);
        }
    }
}