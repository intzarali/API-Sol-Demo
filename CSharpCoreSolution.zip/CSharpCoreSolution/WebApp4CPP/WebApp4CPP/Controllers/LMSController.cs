using Microsoft.AspNetCore.Mvc;
using System.Runtime.InteropServices;

namespace WebApp4CPP.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class LMSController : ControllerBase
    {
        [HttpGet("finalCalc/{nub1}")]
        public int finalCalc(int nub1)
        {
            return CoreDll.Class1.finalCalc(nub1);
        }
    };       
}