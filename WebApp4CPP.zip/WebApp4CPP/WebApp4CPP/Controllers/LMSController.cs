using Microsoft.AspNetCore.Mvc;
using System.Runtime.InteropServices;

namespace WebApp4CPP.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class LMSController : ControllerBase
    {
        [DllImport("C:\\Final-Demo\\LMS_Libs\\x64\\Debug\\LMS_Libs.dll")]

        private static extern int fineCalc(int iDay);

        [HttpGet("finalCalc/{nub1}")]
        public int finalCalc(int nub1)
        {
            return fineCalc(2 *nub1);
        }
    };       
}